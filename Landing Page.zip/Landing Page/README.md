# Landing Page - Photography

As I am a passionate photographer, so I decided to make my last (third) task given by CODSOFT, in CODSOFT Internship Program. 
It is an very very simple and casual looking landing page.
Languages and Frameworks used - HTML 5, CSS 3 and Bootstrap is also used to make it responsive.

-> Looks like -
![Screenshot 2024-09-12 172655](https://github.com/user-attachments/assets/52dfc549-92b7-4ca0-8020-0b3fe8315907)
![Screenshot 2024-09-12 172821](https://github.com/user-attachments/assets/8d20959e-aa6f-421e-9f06-2707f3d67623)

-> This was my final task in CODFOST Internship program.
