# Calculator

This is a simple calculator which performs " ADDITION ", " SUBSTRACTION ", " MULTIPLICATION ", " DIVISION ", " EXPONENTIAL ".
This is one of the task given in the CODSOFT internship in level 1.
The languages used in this are :
   a.) HTML 5
   b.) CSS 3
   c.) JavaScript 
